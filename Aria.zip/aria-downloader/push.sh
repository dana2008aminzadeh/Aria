#!/usr/bin/env bash
# Push the Aria source tree to https://github.com/dana2008aminzadeh/Aria
#
# Usage:
#   ./push.sh <github_token>
#
# Create a fine-grained token with "Contents: Read and write" on that one repository only:
#   https://github.com/settings/tokens?type=beta
# The token is used for a single git push and never written to disk.
set -euo pipefail

TOKEN="${1:-}"
REPO="dana2008aminzadeh/Aria"
BRANCH="main"

if [ -z "$TOKEN" ]; then
  echo "usage: $0 <github_token>" >&2
  exit 1
fi

cd "$(dirname "$0")"

if [ ! -d .git ]; then
  echo "error: .git not found - run this from the Aria repository folder" >&2
  exit 1
fi

echo "== remote:"
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/${REPO}.git"

echo "== files to push:"
git ls-files | wc -l

echo "== secret check (must stay empty):"
git ls-files | grep -iE '\.jks$|\.keystore$|\.apk$|local\.properties$' || echo "   clean"

echo "== pushing to ${REPO} (${BRANCH}) ..."
# token in the URL is only used for this one command
git -c credential.helper= push "https://x-access-token:${TOKEN}@github.com/${REPO}.git" "${BRANCH}"

echo
echo "done: https://github.com/${REPO}"
