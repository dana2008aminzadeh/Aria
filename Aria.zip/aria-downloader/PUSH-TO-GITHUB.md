# فرستادن کد به GitHub — `dana2008aminzadeh/Aria`

> ریپوی تو **خالی** است (`size: 0`, شاخهٔ پیش‌فرض `main`). برای ریپوی خالی «Pull Request» معنا ندارد:
> اولین `push` خودش کل محتوا را روی `main` می‌گذارد. PR فقط وقتی لازم است که ریپو از قبل کد داشته باشد.

همه‌چیز آماده و کامیت‌شده است: **۹۲ فایل**، یک کامیت تمیز.

| فایل | کاربرد |
|---|---|
| `Aria-source-2.0.2.zip` | کل سورس (بدون `.git`) — برای آپلود از مرورگر |
| `Aria-2.0.2.bundle` | مخزن گیت کامل — برای کسی که git دارد |
| `push.sh` | اسکریپت آمادهٔ push با توکن |
| `AriaDownloader-2.0.2-arm64.apk` | فایل نصبی (عمداً داخل گیت نیست) |

---

## راه ۱ — از مرورگر، بدون هیچ دستوری (ساده‌ترین)

1. فایل `Aria-source-2.0.2.zip` را دانلود و **از حالت فشرده خارج کن**.
2. در مرورگر برو به: `https://github.com/dana2008aminzadeh/Aria`
3. روی لینک **uploading an existing file** بزن
   (آدرس مستقیم: `https://github.com/dana2008aminzadeh/Aria/upload/main`)
4. محتوای پوشهٔ استخراج‌شده را انتخاب کن (نه خودِ پوشه) و داخل صفحهٔ آپلود **بکش و رها کن**.
5. پایین صفحه: `Commit changes`.

> روی کامپیوتر آسان است. اگر فقط گوشی داری، حالت «Desktop site» مرورگر را روشن کن؛
> آپلود پوشه در حالت موبایل محدود است. در این حالت راه ۲ یا ۳ بهتر است.

---

## راه ۲ — با git روی کامپیوتر یا Termux

```bash
git clone https://github.com/dana2008aminzadeh/Aria.git
cd Aria
# محتوای zip را داخل همین پوشه کپی کن، بعد:
git add -A
git commit -m "آریا دانلودر 2.0.2"
git push origin main
```

یا با bundle (تاریخچه و کامیت آماده است):

```bash
git clone /path/to/Aria-2.0.2.bundle Aria
cd Aria
git remote set-url origin https://github.com/dana2008aminzadeh/Aria.git
git push -u origin main
```

---

## راه ۳ — من خودم push کنم (توکن موقت بده)

اسکریپت آماده است؛ فقط توکن لازم است:

```bash
chmod +x push.sh
./push.sh ghp_xxxxxxxxxxxxxxxxxxxx
```

**ساخت توکن امن (۲ دقیقه):**
1. `https://github.com/settings/tokens?type=beta` → **Generate new token**
2. Repository access → **Only select repositories** → `Aria`
3. Permissions → **Contents: Read and write** (فقط همین یکی)
4. Expiration → **7 days**
5. توکن را کپی کن و همان لحظه در `push.sh` بگذار.

اگر ترجیح می‌دهی من مستقیم انجام دهم، همان توکن را در چت بفرست؛ بلافاصله push می‌کنم و بعد
از کار، **توکن را در GitHub حذف کن** (Revoke). هیچ توکنی در فایل‌ها یا لاگ‌ها ذخیره نمی‌شود.

---

## چه چیزی عمداً بیرون از گیت ماند

| مورد | چرا |
|---|---|
| `aria-release.jks` و `*.keystore` | **کلید امضای برنامه**؛ انتشارش در ریپوی عمومی یعنی هر کسی می‌تواند نسخهٔ جعلی امضا کند. در `.gitignore` مسدود شد. |
| `*.apk` / `*.aab` | حجم زیاد در تاریخچهٔ گیت. برای انتشار، از **Releases** استفاده کن: `https://github.com/dana2008aminzadeh/Aria/releases/new` و فایل APK را ضمیمه کن. |
| `local.properties` | مسیر SDK مخصوص هر سیستم است. |
| `app/build/`, `.gradle/` | خروجی بیلد. |

⚠️ **نکتهٔ امنیتی:** رمز کلید (`aria123456`) داخل `app/build.gradle` نوشته شده و با push عمومی
می‌شود. تا وقتی خود فایل `aria-release.jks` منتشر نشود خطر جدی ندارد، ولی اگر خواستی حرفه‌ای‌تر
کنی، رمز را به `keystore.properties` (که در `.gitignore` هست) منتقل کن.

---

## بررسی صحت پس از push

در GitHub باید ببینی:

- شاخهٔ `main` با **۹۲ فایل**
- `README.md` و `TEST-REPORT.md` در ریشه
- مسیر `app/src/main/python/aria_dl.py` (موتور yt-dlp)
- `app/src/main/java/ir/aria/downloader/` (۲۵ فایل Kotlin)
- **نباید** هیچ فایل `.jks` یا `.apk` باشد

کامیت آماده: `آریا دانلودر 2.0.2 — دانلودر همه‌کاره اندروید (HTTP + yt-dlp)`
