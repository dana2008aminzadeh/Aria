#!/usr/bin/env bash
# Installs the Android build toolchain outside the persisted workspace (/var/tmp/tc).
# Idempotent: re-running it only downloads what is missing.
set -e
ROOT=/var/tmp/tc
mkdir -p "$ROOT" && cd "$ROOT"

if [ ! -x "$ROOT/jdk17/bin/java" ]; then
  echo "== JDK 17 =="
  curl -sSL -o jdk17.tar.gz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse"
  mkdir -p jdk17 && tar xzf jdk17.tar.gz -C jdk17 --strip-components=1
fi
"$ROOT/jdk17/bin/java" -version

if [ ! -d "$ROOT/android-sdk/platforms/android-33" ]; then
  echo "== Android SDK =="
  curl -sSL -o cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  mkdir -p "$ROOT/android-sdk/cmdline-tools"
  unzip -q -o cmdline-tools.zip -d "$ROOT/android-sdk/cmdline-tools"
  rm -rf "$ROOT/android-sdk/cmdline-tools/latest"
  mv "$ROOT/android-sdk/cmdline-tools/cmdline-tools" "$ROOT/android-sdk/cmdline-tools/latest"
  export JAVA_HOME="$ROOT/jdk17"
  export PATH="$JAVA_HOME/bin:$PATH"
  yes | "$ROOT/android-sdk/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 || true
  "$ROOT/android-sdk/cmdline-tools/latest/bin/sdkmanager" --install "platforms;android-33" "build-tools;33.0.2" "platform-tools" >/dev/null
fi

if [ ! -x "$ROOT/gradle-7.5/bin/gradle" ]; then
  echo "== Gradle 7.5 =="
  curl -sSL -o gradle.zip https://services.gradle.org/distributions/gradle-7.5-bin.zip
  unzip -q -o gradle.zip -d "$ROOT"
fi
echo "TOOLCHAIN_READY"
